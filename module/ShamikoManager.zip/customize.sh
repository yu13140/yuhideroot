SKIPUNZIP=0
ASH_STANDALONE=1
MODDIR=${0%/*}

Castration() {
$BUSYBOX_PATH sed -i "1,/^# This is the last line of the script/d" "$MODPATH/action.sh"
echo "id=ShamikoManager
name=自动添加包名
version=v1.0.0
versionCode=20250215
author=yu13140
description=点击下面的操作，自动为Tricky Store添加包名" >$MODPATH/module.prop
}

if [ "$KSU" = true ] || [ "$APATCH" = true ]; then
    if [ ! -d "/data/adb/modules/tricky_store/" ]; then
        ui_print "你没有安装Tricky Store模块！"
        abort "请安装Tricky Store模块后安装此模块！"
    fi 
    
    if [ "$APATCH" = true ]; then
        BUSYBOX_PATH="/data/adb/ap/bin/busybox"
    elif [ "$KSU" = true ]; then
        BUSYBOX_PATH="/data/adb/ksu/bin/busybox"
    else
        BUSYBOX_PATH="/data/adb/magisk/bin/busybox"
    fi
    
    Castration                  
fi

if [ -z "$KSU" ] && [ -z "$APATCH" ] && [ -n "$MAGISK_VER_CODE" ]; then
    if echo "$MAGISK_VER" | grep -qi "kitsune"; then
        Castration
    fi   
    
    if [ ! -d /data/adb/modules/zygisk_shamiko/ ]; then
        abort "检测到设备上没有安装Shamiko，退出安装"    
    fi

    if [ -f /data/adb/shamiko/whitelist ]; then
        ui_print "识别到当前Shamiko模式为：白名单"
        echo "id=ShamikoManager
name=切换模式+添加包名
version=v1.0.0
versionCode=20250215
author=yu13140
description=点击下面的操作快速切换Shamiko模式，自动添加包名                                                                                       Shamiko当前模式：白名单" >$MODPATH/module.prop
    else
        ui_print "识别到当前Shamiko模式为：黑名单"
        echo "id=ShamikoManager
name=切换模式+添加包名
version=v1.0.0
versionCode=20250215
author=yu13140
description=点击下面的操作快速切换Shamiko模式，自动添加包名                                                                                       Shamiko当前模式：黑名单" >$MODPATH/module.prop
    fi   
fi