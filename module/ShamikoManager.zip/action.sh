echo  "                                        "
    if [ -a /data/adb/shamiko/whitelist ]; then
        rm -f /data/adb/shamiko/whitelist
        echo "- Shamiko已设置黑名单模式"
        echo "id=ShamikoManager
name=切换模式+添加包名
version=v1.0.0
versionCode=20250215
author=yu13140
description=点击下面的操作快速切换Shamiko模式，自动添加包名                                                                                       Shamiko当前模式：黑名单" >/data/adb/modules/ShamikoManager/module.prop
    else
        touch /data/adb/shamiko/whitelist
        echo "- Shamiko已设置白名单模式"
        echo "id=ShamikoManager
name=切换模式+添加包名
version=v1.0.0
versionCode=20250215
author=yu13140
description=点击下面的操作快速切换Shamiko模式，自动添加包名                                                                                       Shamiko当前模式：白名单" >/data/adb/modules/ShamikoManager/module.prop
    fi    
# This is the last line of the script
output_file="/data/adb/tricky_store/target.txt"

# 获取包名函数
get_packages() {
    local type=$1
    local output=$2
    echo "- 正在获取 $type 应用包名..." >&2
    pm list packages $flag | sed 's/package://g' > "$output"
    
    if [ $? -ne 0 ] || [ ! -s "$output" ]; then
        echo "- 错误：$type 应用包名获取失败" >&2
        rm -f "$output"
        return 1
    fi
    return 0
}

if ! get_packages "第三方" "$output_file" -3; then
    exit 3
fi

if ! get_packages "系统" "$output_file" -s; then
    exit 4
fi    
global_count=$(wc -l < "$output_file")

echo "- 成功获取：$global_count 个包名 "