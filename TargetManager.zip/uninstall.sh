rm -rf /data/adb/modules/AAPN 2>/dev/null
rm -f /data/local/tmp/installed_raw_logs.txt
