SKIPUNZIP=0

# --------------------------
# 切换模式 ：编辑 pattern 文件内容为（ logcat 或 monitor ）
# logcat模式 ：占用资源少，但某些设备可能不适用
# am monitor模式 ：任何设备都通用，但占用资源较多
# --------------------------

# 定义路径
RAW_LOG_FILE="/data/local/tmp/installed_raw_logs.txt"
TEST_DURATION=10

# --------------------------
# 初始化：清空旧日志
# --------------------------

if [ ! -d "/data/local/tmp/" ]; then
  mkdir "/data/local/tmp"
fi

if [ ! -d "/data/adb/modules/tricky_store/" ]; then
  ui_print "你没有安装Tricky Store模块！"
  abort "请安装Tricky Store模块后安装此模块！"
fi  

ui_print " 作者：酷安@yu13140 "
ui_print " 自动添加包名至Tricky Store模块 "
ui_print "                                        "
ui_print "========================================"
ui_print " 开始执行日志捕获测试 "
ui_print "========================================"
ui_print "                                        "
ui_print " 这可能需要一些时间 "
: > "$RAW_LOG_FILE"

# --------------------------
# 函数：安全终止后台进程
# --------------------------
safe_kill() {
  local pid=$1
  if kill -0 "$pid" 2>/dev/null; then
    kill "$pid" 2>/dev/null
    wait "$pid" 2>/dev/null  # 等待进程完全退出
  fi
}

# --------------------------
# 步骤1：触发安装事件（抑制后台输出）
# --------------------------
# 自定义APK配置
TEST_APK_NAME="TestApp.apk"
TEST_APK_PATH="$MODPATH/assets/$TEST_APK_NAME"
TEST_PKG_NAME="io.github.a13e300.dsf_detector"  # 必须与APK包名一致

if [ -f "$TEST_APK_PATH" ]; then      
  ui_print "- 测试包: $TEST_PKG_NAME"
  
  # 静默安装
  (pm install -r $TEST_APK_PATH >/dev/null 2>&1) &
  INSTALL_PID=$!
  
  # 等待安装完成
  wait $INSTALL_PID
  INSTALL_RESULT=$?
  
  # 延迟确保事件触发
  sleep 1
else
  ui_print "⚠ 未找到测试包"
fi

# --------------------------
# 步骤2：动态检测日志模式（无后台残留）
# --------------------------
(
  logcat -v time -c >/dev/null 2>&1
  logcat -v time | grep -i "PACKAGE_ADDED" > "${RAW_LOG_FILE}_test"
) &
LOGCAT_PID=$!

# 显示倒计时（无后台进程）
ui_print "- 日志模式检测中..."
for i in $(seq $TEST_DURATION -1 1); do
  printf "\r  █ 剩余时间: %2d 秒" $i
  sleep 1
done
printf "\n"

safe_kill $LOGCAT_PID

# 判断日志模式
if grep -q "PACKAGE_ADDED" "${RAW_LOG_FILE}_test" 2>/dev/null; then  
  ui_print "- 使用 logcat 模式"
  ui_print "logcat" > $MODPATH/pattern 
  chmod 660 $MODPATH/pattern
else  
  ui_print "- 使用 am monitor 模式"
  ui_print "monitor" > $MODPATH/pattern
  chmod 660 $MODPATH/pattern
fi

# --------------------------
# 步骤3：清理测试应用
# --------------------------
if [ -f "$TEST_APK_PATH" ] && [ "$INSTALL_RESULT" -eq 0 ]; then
  ui_print "- 正在清理测试环境..."
  pm uninstall "$TEST_PKG_NAME" >/dev/null 2>&1 && {
    ui_print "  已成功卸载测试应用"
  } || {
    ui_print "⚠ 测试应用卸载失败 (可能未安装)"
  }
fi

rm "${RAW_LOG_FILE}_test" 2>/dev/null
sleep 2
safe_kill $LOG_PID

ui_print "========================================"
ui_print " 模块安装完成 "
ui_print "========================================"