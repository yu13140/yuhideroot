#!/system/bin/sh

# --------------------------
# 切换模式 ：编辑 pattern 文件内容为（ logcat 或 monitor ）
# logcat模式 ：占用资源少，但某些设备可能不适用
# am monitor模式 ：任何设备都通用，但占用资源较多
# --------------------------
   
   rm -rf "/data/adb/modules/AAPN/assets"
   
   (
   while true; do
       RAW_LOG_FILE="/data/local/tmp/installed_raw_logs.txt"
       TEST_DURATION=5
       LOG_METHOD="$(cat /data/adb/modules/AAPN/pattern 2>/dev/null)"
       PACKAGE_FILE="/data/adb/tricky_store/target.txt"

       # 清理旧日志
       rm -f "$RAW_LOG_FILE"       

       if [ "$LOG_METHOD" = "logcat" ]; then
           (logcat -v time | grep -i "PACKAGE_ADDED" >> "$RAW_LOG_FILE") &
           LOGCAT_PID=$!
           sleep "$TEST_DURATION"
           kill "$LOGCAT_PID" 2>/dev/null
           awk -F'dat=package:' '{if ($2) print $2}' "$RAW_LOG_FILE" | awk '{print $1}' | sort -u >> "$PACKAGE_FILE"
       else
           (am monitor >> "$RAW_LOG_FILE") &
           AM_MONITOR_PID=$!
           sleep "$TEST_DURATION"
           kill "$AM_MONITOR_PID" 2>/dev/null
           grep "data=" "$RAW_LOG_FILE" | awk -F'data=' '{print $2}' | awk '{print $1}' | sort -u >> "$PACKAGE_FILE"
       fi

       sort /data/adb/tricky_store/target.txt | uniq >/data/adb/tricky_store/cache.txt
       cat "/data/adb/tricky_store/cache.txt" > "/data/adb/tricky_store/target.txt"
       rm -f /data/adb/tricky_store/cache.txt
       rm -f "$RAW_LOG_FILE"
       sleep 60  # 间隔60秒后再次运行
   done
   ) &