rm -rf /data/adb/modules/AuroraNasa_Installer/
rm -rf /data/adb/modules_update/AuroraNasa_Installer/
rm -rf /data/local/tmp/AuroraNasa_Installer_ClearEnv/
rm -rf /data/local/tmp/yshell/
rm -f /data/local/tmp/remove.sh
rm -f /data/adb/service.d/ARMIAS_Cleanup.sh